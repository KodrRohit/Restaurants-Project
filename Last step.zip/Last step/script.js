document.addEventListener('DOMContentLoaded', function() {
    // Only run if it's the placeOrder page
    if (window.location.pathname.includes("placeOrder.html")) {
        
        // Add event listener for the order form submit action
        let orderForm = document.querySelector('.order-form');
        if (orderForm) {
            orderForm.addEventListener('submit', function(event) {
                event.preventDefault(); // Prevent form submission (if necessary)
                localStorage.removeItem('cartItems'); // Clear cart from localStorage
                console.log("Order submitted, cart cleared.");
            });
        } else {
            console.error("Order form not found on placeOrder page!");
        }

        // You can add any other functionality related to the placeOrder page here
    }

    // Add other event listeners for your cart functionality (like adding items to cart)
    const btnCart = document.querySelector('.btn-cart');
    const cart = document.querySelector('.cart');
    const btnClose = document.querySelector('#cart-close');

    if (btnCart) {
        btnCart.addEventListener('click', () => {
            cart.classList.add('cart-active');
        });
    }

    if (btnClose) {
        btnClose.addEventListener('click', () => {
            cart.classList.remove('cart-active');
        });
    }

    // Other cart functionalities...
    loadContent(); // This is where you initialize the content
});

// Your existing function for adding items to the cart
let itemList = [];

function addCart() {
    let food = this.parentElement;
    let title = food.querySelector('.food-title').innerHTML;
    let price = food.querySelector('.food-price').innerHTML;
    let imgSrc = this.parentElement.querySelector('.food-img').src;

    let newProduct = {title, price, imgSrc};

    // Log or show the new product being added to the cart
    console.log("Food added: ", newProduct);

    placeOrder(title);  // Call the placeOrder function to show the order summary

    if (itemList.find((el) => el.title === newProduct.title)) {
        alert("Product already added in cart.");
        return;
    } else {
        itemList.push(newProduct);
    }
    
    let newProductElement = createCartProduct(title, price, imgSrc);
    let element = document.createElement('div');
    element.innerHTML = newProductElement;
    let cartBasket = document.querySelector('.cart-content');
    cartBasket.append(element);
    loadContent();
}

function createCartProduct(title, price, imgSrc) {
    return `
        <div class="cart-box">
            <img src="${imgSrc}" class="cart-img">
            <div class="detail-box">
                <div class="cart-food-title">${title}</div>
                <div class="price-box">
                    <div class="cart-price">${price}</div>
                    <div class="cart-amt">${price}</div>
                </div>
                <input type="number" value="1" class="cart-quantity">
            </div>
            <i class="fa fa-trash cart-remove"></i>
        </div>
    `;
}

function placeOrder(order) {
    console.log("Food Name: " + order);
    
    let list = document.querySelector('.list');
    
    if (list) {
        let newOrder = document.createElement('li');
        newOrder.innerHTML = order;
        list.appendChild(newOrder);
    } else {
        console.error("The list element is missing in your HTML!");
    }
}

// The rest of your cart-related functions remain the same...
